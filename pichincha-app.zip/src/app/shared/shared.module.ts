import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormFieldModule } from './form-field/form-field.module';
import { ButtonsModule } from './buttons/buttons.module';
import { AlertModule } from './alert/alert.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
  ],
  exports:[
    FormFieldModule,
    ButtonsModule,
    AlertModule,
  ]
})
export class SharedModule { }
